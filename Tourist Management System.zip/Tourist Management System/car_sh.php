<!DOCTYPE html>
<html>
<head>
   
    <title>Booking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet"href="style.css"/>


<style>
body{
	text-align: center;
	background-color : gray;
}
</style>


</head>
<body>


<nav>
    <ul>
<li class="dropdown">
    

        <a href="home.html"><i class="w3-jumbo w3-spin fa fa-home"></i></a>
     
    </div>
  
</li>

 <li class="dropdown">
    <a class="dropbtn">Destination</a>
    <div class="dropdown-content">
      <a href="bandarban.html">Bandarban</a>
      <a href="khagrachori.html">Khagrachori</a>
      <a href="kuakata.html">Kuakata</a>
      <a href="saintmartin.html">St. Martin</a>
      <a href="rangamati.html">Rangamati</a>

     
    </div>
  </li>
  <li><a href="P_table.php">Packages</a></li>
  <li class="dropdown">
    <a class="dropbtn">Bookings</a>
    <div class="dropdown-content">
      <a href="hotel_bk.php">Hotel</a>
      <a href="car_sh.php">Car Rental</a>
    </div>
  </li>
   <li style="float:right"><a href="insert.html">Admin</a></li>
</ul>

<style>
ul {
    list-style-type: none;
    margin: 30;
    padding: 20;
    overflow: hidden;
    background-color: gray;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 30px 30px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 110px;
    box-shadow: 0px 30px 50px 0px rgba(0,0,0,0.5);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 30px 50px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>


</nav>


<b><p>Find a Car</p></b>
<br>
<form action="car_sh.php" method="get">
 <input type="text" text align="center" name="Pick_up_from" placeholder="Pick_up From">
     <input type="text" text align="center" name="Drop_at" placeholder="Drop at"><br> 
     

    <br>
     <input type="submit" name="search" value="Search"> <br><br> 
      
    <br><br>

<p>To Rent a Car please click the Rent buttne</p>
<button><a href="car_bk.php">Rent</a></button>


 </body>
</form>

</html>



<?php

$con=mysqli_connect("localhost","root","","Project");



if(isset($_GET['search']))
{


    $picup=$_GET['Pick_up_from'];
    $drp=$_GET['Drop_at'];

    $sql="select *from car_li where Pick_up_from='$picup' and Drop_at='$drp'";

    $rslt=mysqli_query($con,$sql);

    
echo "<br>";

  if ($rslt->num_rows > 0) {
while($row = mysqli_fetch_array($rslt) ) { 



echo "<table border='1'>
<tr>
<th>Car Id</th>
<th>Car Name</th>
<th>Pick-up From</th>
<th>Drop at</th>
<th>Cost</th>
</tr>";  

  $ci=$row["Car_id"];
  $nm= $row["Car_name"];
  $pkup=$row["Pick_up_from"];
  $drp=$row["Drop_at"];
  $cost=$row["Cost"];

echo "<tr>";
echo "<td>" . $ci. "</td>";
echo "<td>" . $nm. "</td>";
echo "<td>" . $pkup. "</td>";
echo "<td>" . $drp. "</td>";
echo "<td>" . $cost. "</td>";

echo "</tr>";
}
echo "</table>";

}
else {
    echo"Oppps ! NO Data found ";
}



mysqli_close($con);
}




?>