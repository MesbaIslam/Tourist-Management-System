<!DOCTYPE html>
<html>
<head>
   
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet"href="style.css"/>


<style>
body{
	text-align: center;
	background-color : gray;
}
</style>


</head>
<body>

<nav>
    <ul>
<li class="dropdown">
    

        <a href="home.html"><i class="w3-jumbo w3-spin fa fa-home"></i></a>
     
    </div>
  
</li>

 <li class="dropdown">
    <a class="dropbtn">Destination</a>
    <div class="dropdown-content">
      <a href="bandarban.html">Bandarban</a>
      <a href="khagrachori.html">Khagrachori</a>
      <a href="kuakata.html">Kuakata</a>
      <a href="saintmartin.html">St. Martin</a>
      <a href="rangamati.html">Rangamati</a>

     
    </div>
  </li>
  <li><a href="P_table.php">Packages</a></li>
  <li class="dropdown">
    <a class="dropbtn">Bookings</a>
    <div class="dropdown-content">
      <a href="hotel_bk.php">Hotel</a>
      <a href="car_sh.php">Car Rental</a>
    </div>
  </li>
   <li style="float:right"><a href="insert.html">Admin</a></li>
</ul>

<style>
ul {
    list-style-type: none;
    margin: 30;
    padding: 20;
    overflow: hidden;
    background-color: gray;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 30px 30px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 110px;
    box-shadow: 0px 30px 50px 0px rgba(0,0,0,0.5);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 30px 50px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>


</nav>





<body>
<div class="center">
	<form action="edit.php"method="post">
		To Update a package Please enter The TOUR ID first <br></br>
		<input type="int" name="Tour_id" placeholder="Tour Id">
        </br><br>

		<input type="text" name="Guide_Name" placeholder="Guide Name">
        </br><br>
        <input type="int" name="Contact" placeholder="Contact">
    <br><br>
    <input type="text" name="Package_name" placeholder="Package_Name">
</br><br>

<input type="text" name="Category" placeholder="Category">
</br><br>
<input type="text" name="Tour_place" placeholder="Tour Place">
</br><br>
<input type="int" name="Days" placeholder="Days">
</br><br>
<input type="int" name="Amount" placeholder="Amount">
</br>
<tr>
<td colspan="2"align="center"><input type="submit" name="update" Value="UPDATE">


</td>
</tr>
<br><br>
To SEE THE PACKAGE Details hit the SHOW button
<br>
<tr><td > <input type=submit name=showButton value=Show method=post></td></tr>

</form>
<br>
<br>

</div>
</body>
</html>




<?php

$con=mysqli_connect("localhost","root","","Project");




if (isset($_POST['showButton']))
{
 

    $query ="SELECT Tour_id,Guide_Name,Contact,Package_name,Category,Tour_place,Days,Amount FROM Package ";
  $result=mysqli_query($con,$query);





echo "<table border='1'>
<tr>
<th>Tour_id</th>
<th>Guide_Name</th>
<th>Contact</th>
<th>Package_name</th>
<th>Category</th>
<th>Tour_place</th>
<th>Days</th>
<th>Amount</th>
</tr>";

  if ($result->num_rows > 0) {
while($row = mysqli_fetch_array($result) ) {   

  $ti=$row["Tour_id"];
  $nm= $row["Guide_Name"];
  $cont=$row["Contact"];
  $pac=$row["Package_name"];
  $cat=$row["Category"];
  $tp=$row["Tour_place"];
  $day=$row["Days"];
  $amo=$row["Amount"];

echo "<tr>";
echo "<td>" . $ti. "</td>";
echo "<td>" . $nm. "</td>";
echo "<td>" . $cont. "</td>";
echo "<td>" . $pac. "</td>";
echo "<td>" . $cat. "</td>";
echo "<td>" . $tp. "</td>";
echo "<td>" . $day. "</td>";
echo "<td>" . $amo. "</td>";
echo "</tr>";
}
echo "</table>";

echo"<br>";

mysqli_close($con);




}
 
}

if(isset($_POST['update']))
{

$Guide_Name=$_POST['Guide_Name'];
$Contact=$_POST['Contact'];
$Package_name=$_POST['Package_name'];
$Category=$_POST['Category'];
$Tour_place=$_POST['Tour_place'];
$Days=$_POST['Days'];
$Amount=$_POST['Amount'];
 $id=$_POST['Tour_id'];
$sql = "UPDATE Package SET Guide_Name = '$Guide_Name', Contact = '$Contact', Package_name = '$Package_name', Category = '$Category', Tour_place = '$Tour_place',Days='$Days',Amount='$Amount' WHERE Tour_id = '$id'";
$result=mysqli_query($con,$sql);
if(!$result){ 
	echo "update failed!!   ";
	die ("Couldn't execute query: ". mysqli_connect_error());
}
else
{
	echo "You have updated entry Id= ".$id."successfully :) Click SHOW to see Packages !.";
}

}
 ?>
