<!DOCTYPE html>
<html>
<head>
   
    <title>Bookings</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet"href="style.css"/>


<style>
body{
    text-align: center;
    background-color : gray;
}
</style>


</head>
<body>


<nav>
    <ul>
<li class="dropdown">
    

        <a href="home.html"><i class="w3-jumbo w3-spin fa fa-home"></i></a>
     
    </div>
  
</li>

 <li class="dropdown">
    <a class="dropbtn">Destination</a>
    <div class="dropdown-content">
     <a href="bandarban.html">Bandarban</a>
      <a href="khagrachori.html">Khagrachori</a>
      <a href="kuakata.html">Kuakata</a>
      <a href="saintmartin.html">St. Martin</a>
      <a href="rangamati.html">Rangamati</a>

     
    </div>
  </li>
  <li><a href="P_table.php">Packages</a></li>
  <li class="dropdown">
    <a class="dropbtn">Bookings</a>
    <div class="dropdown-content">
      <a href="hotel_bk.php">Hotel</a>
      <a href="car_sh.php">Car Rental</a>
    </div>
  </li>
   <li style="float:right"><a href="insert.html">Admin</a></li>
</ul>

<style>
ul {
    list-style-type: none;
    margin: 30;
    padding: 20;
    overflow: hidden;
    background-color: gray;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 30px 30px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 110px;
    box-shadow: 0px 30px 50px 0px rgba(0,0,0,0.5);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 30px 50px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>


</nav>



<body>
<div class="center">
    <form action="hbook.php"method="post">
    <br><br>
    <b><p>please Fill The form To Book a Hotel <p></b>
        <br>
        
        <input type="text" name="Name" placeholder="Guest Name">
        </br><br>
        <input type="int" name="Contact" placeholder="Contact">
    <br><br>
    <input type="int" name="Hotel_id" placeholder="Hotel ID">
</br><br>
Check-in Date:-<br>
<input type="date" name="Check_in_date" placeholder="Check-in Date">
</br><br>
Check-out Date:<br>
<input type="date" name="Check_out_date" placeholder="Check-out Date">
</br><br>

<input type="int" name="Guest_no" placeholder="Guest NO">
</br>
<br>
<input type="email" name="Email" placeholder="Email">

<br><br>

<tr>
<td colspan="2"align="center"><input type="submit" name="insert" Value="Insert">
  </td>
</tr>
<br> <br>
To Update a package Please enter The Book ID first <br></br>
    <input type="int" name="Book_ID" placeholder="Book ID">
        </br><br>


<td colspan="2"align="center"><input type="submit" name="update" Value="UPDATE">


</td>
</tr>
<br><br>
To SEE Your Booking hit the SHOW button
<br>
<tr><td > <input type=submit name=showButton value=Booking method=post></td></tr>

</form>
<br>
<br>

</div>
</body>
</html>




<?php

$con=mysqli_connect("localhost","root","","Project");



if(isset($_POST['insert']))
{

$Name=$_POST['Name'];
$Contact=$_POST['Contact'];
$Hotel_id=$_POST['Hotel_id'];
$Check_in_date=$_POST['Check_in_date'];
$Check_out_date=$_POST['Check_out_date'];
$Guest_no=$_POST['Guest_no'];
$Email=$_POST['Email'];


$sqli=" INSERT INTO hotel_bk(Name,Contact,Hotel_id,Check_in_date,Check_out_date,Guest_no,Email)
values('$Name','$Contact','$Hotel_id','$Check_in_date','$Check_out_date','$Guest_no','$Email')";


if (mysqli_query($con, $sqli)) {

    echo "New records created successfully";
} else {
    echo "Error: " . $sqli . "<br>" . mysqli_error($con);
}
 echo"</br>";



header("refresh:2; url=hbook.php");

mysqli_close($con);

}




if (isset($_POST['showButton']))
{
 

    $query ="SELECT hotel_bk.Book_ID,hotel_bk.Name,hotel_bk.Contact,hotel_li.Hotel_name,hotel_bk.Check_in_date,hotel_bk.Check_out_date,hotel_bk.Guest_no,hotel_bk.Email
    FROM hotel_bk
    INNER JOIN hotel_li
    ON hotel_bk.Hotel_id=hotel_li.Hotel_id";
  $result=mysqli_query($con,$query);





echo "<table border='1'>
<tr>
<th>Book ID</th>
<th>Name</th>
<th>Contact</th>
<th>Hotel Name</th>
<th>Check-in Date</th>
<th>Check-out Date</th>
<th>Guest No</th>
<th>Email</th>

</tr>";

  if ($result->num_rows > 0) {
while($row = mysqli_fetch_array($result) ) {   

  $bi=$row["Book_ID"];
  $nm= $row["Name"];
  $cont=$row["Contact"];
  $hn=$row["Hotel_name"];
  $ckin=$row["Check_in_date"];
  $ckout=$row["Check_out_date"];
  $gstno=$row["Guest_no"];
  $email=$row["Email"];

echo "<tr>";
echo "<td>" . $bi. "</td>";
echo "<td>" . $nm. "</td>";
echo "<td>" . $cont. "</td>";
echo "<td>" . $hn. "</td>";
echo "<td>" . $ckin. "</td>";
echo "<td>" . $ckout. "</td>";
echo "<td>" . $gstno. "</td>";
echo "<td>" . $email. "</td>";

echo "</tr>";
}
echo "</table>";

echo"<br>";

mysqli_close($con);




}
 
}

if(isset($_POST['update']))
{

$Name=$_POST['Name'];
$Contact=$_POST['Contact'];
$Hotel_id=$_POST['Hotel_id'];
$Check_in_date=$_POST['Check_in_date'];
$Check_out_date=$_POST['Check_out_date'];
$Guest_no=$_POST['Guest_no'];
$Email=$_POST['Email'];

 $id=$_POST['Book_ID'];


$sql = "UPDATE hotel_bk SET Name = '$Name', Contact = '$Contact', Hotel_id = '$Hotel_id', Check_in_date = '$Check_in_date', Check_out_date = '$Check_out_date',Guest_no='$Guest_no' WHERE Book_ID = '$id'";

$result=mysqli_query($con,$sql);
if(!$result){ 
    echo "update failed!!   ";
    die ("Couldn't execute query: ". mysqli_connect_error());
}
else
{
    echo "You have updated entry Id= ".$id."successfully :) Click SHOW to see Booking !.";
}

}
 ?>
