<!DOCTYPE html>
<html>
<head>
   
    <title>Rent a Car</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet"href="style.css"/>


<style>
body{
    text-align: center;
    background-color : gray;
}
</style>


</head>
<body>


<nav>
    <ul>
<li class="dropdown">
    

        <a href="home.html"><i class="w3-jumbo w3-spin fa fa-home"></i></a>
     
    </div>
  
</li>

 <li class="dropdown">
    <a class="dropbtn">Destination</a>
    <div class="dropdown-content">
     <a href="bandarban.html">Bandarban</a>
      <a href="khagrachori.html">Khagrachori</a>
      <a href="kuakata.html">Kuakata</a>
      <a href="saintmartin.html">St. Martin</a>
      <a href="rangamati.html">Rangamati</a>

     
    </div>
  </li>
  <li><a href="P_table.php">Packages</a></li>
  <li class="dropdown">
    <a class="dropbtn">Bookings</a>
    <div class="dropdown-content">
      <a href="hotel_bk.php">Hotel</a>
      <a href="car_sh.php">Car Rental</a>
    </div>
  </li>
   <li style="float:right"><a href="insert.html">Admin</a></li>
</ul>

<style>
ul {
    list-style-type: none;
    margin: 30;
    padding: 20;
    overflow: hidden;
    background-color: gray;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 30px 30px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 110px;
    box-shadow: 0px 30px 50px 0px rgba(0,0,0,0.5);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 30px 50px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>


</nav>




<body>
<div class="center">
    <form action="car_bk.php"method="post">
    <br><br>
    <b><p>please Fill The form To Rent a Car <p></b>
        <br>
        
        <input type="text" name="Cus_name" placeholder="Customer Name">
        </br><br>
        <input type="int" name="Contact" placeholder="Contact">
    <br><br>
    <input type="int" name="Car_id" placeholder="Car ID">
</br><br>
Pick-up Date:-<br>
<input type="date" name="pick_up_date">
</br><br>
Drop-off Date:<br>
<input type="date" name="Drop_off">
</br><br>


<tr>
<td colspan="2"align="center"><input type="submit" name="insert" Value="Rent">
  </td>
</tr>
<br> <br>
To Edit your Rental Please enter The Book ID first <br></br>
    <input type="int" name="Book_id" placeholder="Book ID">
        </br><br>


<td colspan="2"align="center"><input type="submit" name="update" Value="UPDATE">


</td>
</tr>
<br><br>
To SEE Your Rental hit the SHOW button
<br>
<tr><td > <input type=submit name=showButton value=Rental method=post></td></tr>

</form>
<br>
<br>

</div>
</body>
</html>




<?php

$con=mysqli_connect("localhost","root","","Project");



if(isset($_POST['insert']))
{

$Cus_name=$_POST['Cus_name'];
$Contact=$_POST['Contact'];
$Car_id=$_POST['Car_id'];
$pick_up_date=$_POST['pick_up_date'];
$Drop_off=$_POST['Drop_off'];


$sqli=" INSERT INTO car_bk(Cus_name,Contact,Car_id,pick_up_date,Drop_off)
values('$Cus_name','$Contact','$Car_id','$pick_up_date','$Drop_off')";


if (mysqli_query($con, $sqli)) {

    echo "New records created successfully";
} else {
    echo "Error: " . $sqli . "<br>" . mysqli_error($con);
}
 echo"</br>";



header("refresh:2; url=car_bk.php");

mysqli_close($con);

}




if (isset($_POST['showButton']))
{
 

    $query ="SELECT car_bk.Book_id,car_bk.Cus_name,car_bk.Contact,car_li.Car_name,car_bk.pick_up_date,car_bk.Drop_off
    FROM car_bk
    INNER JOIN car_li
    ON car_bk.Car_id=car_li.Car_id";
  $result=mysqli_query($con,$query);





echo "<table border='1'>
<tr>
<th>Book ID</th>
<th>Customer Name</th>
<th>Contact</th>
<th>Car Name</th>
<th>Pick-up Date</th>
<th>Drop off</th>


</tr>";

  if ($result->num_rows > 0) {
while($row = mysqli_fetch_array($result) ) {   

  $bi=$row["Book_id"];
  $nm= $row["Cus_name"];
  $cont=$row["Contact"];
  $cn=$row["Car_name"];
  $pkup=$row["pick_up_date"];
  $drp=$row["Drop_off"];


echo "<tr>";
echo "<td>" . $bi. "</td>";
echo "<td>" . $nm. "</td>";
echo "<td>" . $cont. "</td>";
echo "<td>" . $cn. "</td>";
echo "<td>" . $pkup. "</td>";
echo "<td>" . $drp. "</td>";

echo "</tr>";
}
echo "</table>";

echo"<br>";

mysqli_close($con);




}
 
}

if(isset($_POST['update']))
{

$Cus_name=$_POST['Cus_name'];
$Contact=$_POST['Contact'];
$Car_id=$_POST['Car_id'];
$pick_up_date=$_POST['pick_up_date'];
$Drop_off=$_POST['Drop_off'];

 $Book_id=$_POST['Book_id'];


$sql = "UPDATE car_bk SET Cus_name = '$Cus_name', Contact = '$Contact', Car_id = '$Car_id', pick_up_date = '$pick_up_date', Drop_off = '$Drop_off' WHERE Book_id = '$Book_id'";

$result=mysqli_query($con,$sql);
if(!$result){ 
    echo "update failed!!   ";
    die ("Couldn't execute query: ". mysqli_connect_error());
}
else
{
    echo "You have updated entry Id= ".$id."successfully :) Click SHOW to see Booking !.";
}

}
 ?>
