-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2017 at 02:41 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_bk`
--

CREATE TABLE `car_bk` (
  `Book_id` int(50) NOT NULL,
  `Cus_name` varchar(30) NOT NULL,
  `Contact` int(30) NOT NULL,
  `Car_id` int(30) NOT NULL,
  `pick_up_date` date NOT NULL,
  `Drop_off` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_bk`
--

INSERT INTO `car_bk` (`Book_id`, `Cus_name`, `Contact`, `Car_id`, `pick_up_date`, `Drop_off`) VALUES
(1, 'babu', 876543, 2, '2017-12-13', '2017-12-14'),
(2, 'ontic', 123456, 2, '2020-12-17', '0000-00-00'),
(3, 'hazi', 4567321, 2, '2017-12-05', '2017-12-06');

-- --------------------------------------------------------

--
-- Table structure for table `car_li`
--

CREATE TABLE `car_li` (
  `Car_id` int(50) NOT NULL,
  `Car_name` varchar(30) NOT NULL,
  `Pick_up_from` varchar(40) NOT NULL,
  `Drop_at` varchar(40) NOT NULL,
  `Cost` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_li`
--

INSERT INTO `car_li` (`Car_id`, `Car_name`, `Pick_up_from`, `Drop_at`, `Cost`) VALUES
(1, 'af', 'sda', 'saf', 233),
(2, 'BMW', 'Dhaka', 'Bandarban', 6000);

-- --------------------------------------------------------

--
-- Table structure for table `hotel_bk`
--

CREATE TABLE `hotel_bk` (
  `Book_ID` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Contact` int(13) NOT NULL,
  `Hotel_id` int(11) NOT NULL,
  `Check_in_date` date NOT NULL,
  `Check_out_date` date NOT NULL,
  `Guest_no` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_bk`
--

INSERT INTO `hotel_bk` (`Book_ID`, `Name`, `Contact`, `Hotel_id`, `Check_in_date`, `Check_out_date`, `Guest_no`, `Email`) VALUES
(1, 'abu', 1234, 1, '2017-12-19', '2017-12-20', 1, 'ffqw@gmail'),
(2, 'shakil', 67890433, 3, '2017-12-20', '2017-12-27', 4, 'gwa@hrdj.com'),
(3, '', 0, 0, '0000-00-00', '0000-00-00', 0, ''),
(4, '', 0, 0, '0000-00-00', '0000-00-00', 0, ''),
(5, 'ontik', 123456, 2, '2017-12-20', '2017-12-22', 5, 'abc@gmail.com'),
(6, 'shehmaz', 1912682712, 2, '2017-12-19', '2017-12-20', 3, 'shehmaz123@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_li`
--

CREATE TABLE `hotel_li` (
  `Hotel_id` int(50) NOT NULL,
  `Hotel_name` varchar(50) NOT NULL,
  `Location` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Hot_line` int(13) NOT NULL,
  `Cost` int(50) NOT NULL,
  `Guests` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_li`
--

INSERT INTO `hotel_li` (`Hotel_id`, `Hotel_name`, `Location`, `Address`, `Hot_line`, `Cost`, `Guests`) VALUES
(1, 'askkjk', 'chittagong', 'chitagong', 235789, 3000, '3'),
(2, 'sheraton', 'Dhaka', 'dhaka', 12345, 7000, '3'),
(3, 'blue moon', 'Dhaka', 'khilgone', 234567, 10000, '4');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `Guide_Name` varchar(50) NOT NULL,
  `Contact` int(13) NOT NULL,
  `Tour_id` int(11) NOT NULL,
  `Package_name` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Tour_place` varchar(50) NOT NULL,
  `Days` int(11) NOT NULL,
  `Amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`Guide_Name`, `Contact`, `Tour_id`, `Package_name`, `Category`, `Tour_place`, `Days`, `Amount`) VALUES
('kabir', 1656564, 31, 'bandarban', 'premium', 'bandarban', 5, 4000),
('rabbi', 98665432, 32, 'bandarban', 'premium', 'bandarban', 4, 5000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_bk`
--
ALTER TABLE `car_bk`
  ADD PRIMARY KEY (`Book_id`);

--
-- Indexes for table `car_li`
--
ALTER TABLE `car_li`
  ADD PRIMARY KEY (`Car_id`);

--
-- Indexes for table `hotel_bk`
--
ALTER TABLE `hotel_bk`
  ADD PRIMARY KEY (`Book_ID`);

--
-- Indexes for table `hotel_li`
--
ALTER TABLE `hotel_li`
  ADD PRIMARY KEY (`Hotel_id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`Tour_id`),
  ADD KEY `Guide_Name` (`Guide_Name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_bk`
--
ALTER TABLE `car_bk`
  MODIFY `Book_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `car_li`
--
ALTER TABLE `car_li`
  MODIFY `Car_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hotel_bk`
--
ALTER TABLE `hotel_bk`
  MODIFY `Book_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hotel_li`
--
ALTER TABLE `hotel_li`
  MODIFY `Hotel_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `Tour_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
