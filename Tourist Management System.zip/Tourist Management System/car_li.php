<!DOCTYPE html>
<html>
<head>
   
    <title>Car Rental</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet"href="style.css"/>


<style>
body{
	text-align: center;
	background-color : gray;
}
</style>


</head>
<body>


<nav>
    <ul>
<li class="dropdown">
    

        <a href="home.html"><i class="w3-jumbo w3-spin fa fa-home"></i></a>
     
    </div>
  
</li>

 <li class="dropdown">
    <a class="dropbtn">Destination</a>
    <div class="dropdown-content">
     <a href="bandarban.html">Bandarban</a>
      <a href="khagrachori.html">Khagrachori</a>
      <a href="kuakata.html">Kuakata</a>
      <a href="saintmartin.html">St. Martin</a>
      <a href="rangamati.html">Rangamati</a>
     
    </div>
  </li>
  <li><a href="P_table.php">Packages</a></li>
  <li class="dropdown">
    <a class="dropbtn">Bookings</a>
    <div class="dropdown-content">
      <a href="hotel_bk.php">Hotel</a>
      <a href="car_sh.php">Car Rental</a>
    </div>
  </li>
   <li style="float:right"><a href="insert.html">Admin</a></li>
</ul>

<style>
ul {
    list-style-type: none;
    margin: 30;
    padding: 20;
    overflow: hidden;
    background-color: gray;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 30px 30px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 110px;
    box-shadow: 0px 30px 50px 0px rgba(0,0,0,0.5);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 30px 50px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>


</nav>





<body>
<div class="center">
	<form action="car_li.php"method="post">
    <br><br>
    <b><p>please Fill The form To Add Car List<p><b>
		
		<input type="text" name="Car_name" placeholder="Car Name">
        </br><br>
        <input type="text" name="Pick_up_from" placeholder="Pick-up From">
    <br><br>
    <input type="text" name="Drop_at" placeholder="Drop at">
</br><br>

<input type="int" name="Cost" placeholder="Cost">
</br><br>

<tr>
<td colspan="2"align="center"><input type="submit" name="insert" Value="Insert">
  </td>
</tr>
<br> <br>
To Update a package Please enter The Car ID first <br></br>
    <input type="int" name="Car_id" placeholder="Car Id">
        </br><br>


<td colspan="2"align="center"><input type="submit" name="update" Value="UPDATE">


</td>
</tr>
<br><br>
To SEE THE Car Lists hit the SHOW button
<br>
<tr><td > <input type=submit name=showButton value=Show method=post></td></tr>

</form>
<br>
<br>

</div>
</body>
</html>




<?php

$con=mysqli_connect("localhost","root","","Project");



if(isset($_POST['insert']))
{

$Car_name=$_POST['Car_name'];
$Pick_up_from=$_POST['Pick_up_from'];
$Drop_at=$_POST['Drop_at'];
$Cost=$_POST['Cost'];



$sqli=" INSERT INTO car_li(Car_name,Pick_up_from,Drop_at,Cost)
values('$Car_name','$Pick_up_from','$Drop_at','$Cost')";


if (mysqli_query($con, $sqli)) {

    echo "New records created successfully";
} else {
    echo "Error: " . $sqli . "<br>" . mysqli_error($con);
}
 echo"</br>";



header("refresh:2; url=car_li.php");

mysqli_close($con);

}




if (isset($_POST['showButton']))
{
 

    $query ="SELECT Car_id,Car_name,Pick_up_from,Drop_at,Cost FROM car_li ";
  $result=mysqli_query($con,$query);





echo "<table border='1'>
<tr>
<th>Car Id</th>
<th>Car_name</th>
<th>Pick-up From</th>
<th>Drop at</th>
<th>Cost</th>

</tr>";

  if ($result->num_rows > 0) {
while($row = mysqli_fetch_array($result) ) {   

  $ci=$row["Car_id"];
  $nm= $row["Car_name"];
  $pic=$row["Pick_up_from"];
  $drp=$row["Drop_at"];
  $cos=$row["Cost"];

echo "<tr>";
echo "<td>" . $ci. "</td>";
echo "<td>" . $nm. "</td>";
echo "<td>" . $pic. "</td>";
echo "<td>" . $drp. "</td>";
echo "<td>" . $cos. "</td>";

echo "</tr>";
}
echo "</table>";

echo"<br>";

mysqli_close($con);




}
 
}

if(isset($_POST['update']))
{

$Car_name=$_POST['Car_name'];
$Pick_up_from=$_POST['Pick_up_from'];
$Drop_at=$_POST['Drop_at'];
$Cost=$_POST['Cost'];

 $Car_id=$_POST['Car_id'];


$sql = "UPDATE car_li SET Car_name = '$Car_name', Pick_up_from = '$Pick_up_from', Drop_at = '$Drop_at',Cost='$Cost' WHERE Car_id = '$Car_id'";
$result=mysqli_query($con,$sql);
if(!$result){ 
	echo "update failed!!   ";
	die ("Couldn't execute query: ". mysqli_connect_error());
}
else
{
	echo "You have updated entry Id= ".$id."successfully :) Click SHOW to see the Car list !.";
}

}

 ?>
